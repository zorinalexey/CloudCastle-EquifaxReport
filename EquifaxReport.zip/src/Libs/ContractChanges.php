<?php

namespace CloudCastle\EquifaxReport\Libs;

class ContractChanges
{

}