<?php

namespace CloudCastle\EquifaxReport\Libs;

class ContractAmount
{
    public ?float $sum = null;
    public string $currency = 'RUB';
    public ?float $security_sum = null;
}