<?php

namespace CloudCastle\EquifaxReport\Libs;

class JointDebtors
{
    public ?int $count = null;
}