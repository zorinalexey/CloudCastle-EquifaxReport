<?php

namespace CloudCastle\EquifaxReport\Libs;

class Commercial
{

}