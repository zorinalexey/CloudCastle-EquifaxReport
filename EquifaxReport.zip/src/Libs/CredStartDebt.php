<?php

namespace CloudCastle\EquifaxReport\Libs;

class CredStartDebt
{
    public ?string $date = null;
}