<?php

namespace CloudCastle\EquifaxReport\Libs;

class FullCost
{
    public ?string $percent = null;
    public ?string $sum = null;
    public ?string $date = null;
}